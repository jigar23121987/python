#python Scripts\ocrpdf.py
import os
import shutil
import subprocess
import re
import time
import datetime

# Record the start time
start_time = time.time()

# Define start time
start_time1 = datetime.datetime.now()

# def clear_screen():
#     os.system('cls' if os.name == 'nt' else 'clear')

def remove_special_characters(filename):
    # Define a regular expression pattern to match special characters
    pattern = r'[^\w\-_. ]'
    # Replace special characters with an empty string
    clean_filename = re.sub(pattern, '', filename)
    return clean_filename
# Function to convert scanned PDFs into searchable PDFs

def convert_to_searchable_pdf(input_folder, output_parent_folder):
    # Create dynamic output folder path
    output_folder = os.path.join(output_parent_folder, os.path.basename(input_folder))
    os.makedirs(output_folder, exist_ok=True)
    
    # Iterate through each PDF file in the input folder
    for filename in os.listdir(input_folder):
        if filename.endswith(".pdf"):
            input_pdf_path = os.path.join(input_folder, filename)

            cleaned_filename = remove_special_characters(filename)


            output_pdf_path = os.path.join(output_folder, cleaned_filename)
            
            # Command to run ocrmypdf with the --force-ocr option
            command = ['ocrmypdf', '--force-ocr', input_pdf_path, output_pdf_path]

            # Run the command
            subprocess.run(command)
            print(f"Converted '{input_pdf_path}' to searchable PDF.")

# Function to process multiple input folders
def process_folders(input_folders, output_parent_folder):
    for input_folder in input_folders:
        convert_to_searchable_pdf(input_folder, output_parent_folder)


# Example usage
input_folders = ["input/DMS"]  # List of input folders
output_parent_folder = "output"  # Parent folder to save output folders

# Process each input folder and create dynamic output folders
process_folders(input_folders, output_parent_folder)

# # Iterate through all files in the root directory and its subfolders
# for root, dirs, files in os.walk(root_folder_path):
#     for filename in files:
#         if filename.endswith('.pdf'):

#             # Remove special characters from the filename
#             cleaned_filename = remove_special_characters(filename)

#             input_pdf_path = os.path.join(root, filename)
#             output_pdf_path = os.path.join(output_root_folder_path, os.path.relpath(root, root_folder_path), cleaned_filename)

#             # Convert scanned PDF to searchable PDF
#             try:
#                 convert_to_searchable_pdf(input_pdf_path, output_pdf_path)
#                 print("Converted:", input_pdf_path, "to", output_pdf_path)
#             except Exception as e:
#                 print(f"Error converting {input_pdf_path}: {e}")

# Record the end time
end_time = time.time()

# Define end time
end_time1 = datetime.datetime.now()

# Calculate the total time
total_time = end_time - start_time

# Print the total time
print("Total time taken:", total_time, "seconds")

# # Call the function to clear the screen
# clear_screen()

# Calculate total time
total_time1 = end_time1 - start_time1

# Extract hours, minutes, and seconds from total time
hours, remainder = divmod(total_time1.seconds, 3600)
minutes, seconds = divmod(remainder, 60)

# Print total time
print(f"Total time: {hours} hours, {minutes} minutes, {seconds} seconds.")
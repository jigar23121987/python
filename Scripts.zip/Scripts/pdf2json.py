import os
import subprocess
import json
from PyPDF2 import PdfReader

# Function to perform OCR on a PDF file using ocrmypdf
def perform_ocr(input_pdf_path, output_pdf_path):
    # Command to run ocrmypdf with the --force-ocr option
    command = ['ocrmypdf', '--force-ocr', input_pdf_path, output_pdf_path]
    
    # Run the command
    subprocess.run(command)

# Function to extract text from OCR'd PDF file
def extract_text_from_pdf(ocr_pdf_path):
    with open(ocr_pdf_path, 'rb') as f:
        pdf_reader = PdfReader(f)
        text = ''
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text

# Function to process a folder and perform OCR on PDF files
def process_folder(input_folder_path, output_folder_path):
    for root, dirs, files in os.walk(input_folder_path):
        for file_name in files:
            if file_name.endswith('.pdf'):
                # Input PDF file path
                input_pdf_path = os.path.join(root, file_name)
                
                # Output PDF file path (with '_ocr' suffix)
                output_pdf_path = os.path.join(output_folder_path, file_name.replace('.pdf', '.pdf'))
                
                # Perform OCR on the PDF file
                perform_ocr(input_pdf_path, output_pdf_path)
                
                # Extract text from OCR'd PDF file
                text = extract_text_from_pdf(output_pdf_path)
                
                # Generate OCR JSON file path
                ocr_json_path = os.path.join(output_folder_path, file_name.replace('.pdf', '.json'))
                
                # Create JSON with extracted text
                with open(ocr_json_path, 'w') as json_file:
                    json.dump({'pdf_file': file_name, 'extracted_text': text}, json_file, indent=4)

# Function to process multiple input folders
def process_multiple_folders(input_root_folder, output_root_folder):
    for folder_name in os.listdir(input_root_folder):
        input_folder_path = os.path.join(input_root_folder, folder_name)
        if os.path.isdir(input_folder_path):
            # Dynamically create output folder
            output_folder_path = os.path.join(output_root_folder, folder_name + '_ocr')
            os.makedirs(output_folder_path, exist_ok=True)
            
            # Perform OCR on PDF files in the input folder
            process_folder(input_folder_path, output_folder_path)

# Example usage
input_root_folder = 'input'
output_root_folder = 'output'

# Process multiple input folders and perform OCR
process_multiple_folders(input_root_folder, output_root_folder)

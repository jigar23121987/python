import fitz  # PyMuPDF
import pytesseract
from PIL import Image

# Function to OCR a PDF and extract text
def ocr_pdf(input_pdf_path, output_text_path):
    # Open the PDF file
    pdf_document = fitz.open(input_pdf_path)

    # Initialize an empty string to store extracted text
    extracted_text = ""

    # Iterate through each page in the PDF
    for page_number in range(len(pdf_document)):
        # Get the page
        page = pdf_document.load_page(page_number)
        
        # Convert the page to an image
        pix = page.get_pixmap()

        # Convert the pixmap to a Pillow image
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

        # Perform OCR on the image
        text = pytesseract.image_to_string(img, lang='eng')

        # Append the extracted text to the output
        extracted_text += text

    # Close the PDF document
    pdf_document.close()

    # Write the extracted text to a text file
    with open(output_text_path, "w", encoding="utf-8") as text_file:
        text_file.write(extracted_text)

# Example usage
input_pdf_path = "input.pdf"
output_text_path = "output.txt"
ocr_pdf(input_pdf_path, output_text_path)

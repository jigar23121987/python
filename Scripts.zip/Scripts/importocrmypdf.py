import ocrmypdf

def ocr(file_path, save_path):
    ocrmypdf.ocr(file_path, save_path)

ocr("input.pdf","output.pdf")